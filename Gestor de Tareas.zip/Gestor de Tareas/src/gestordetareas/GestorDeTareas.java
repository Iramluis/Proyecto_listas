/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package gestordetareas;

import java.util.Scanner;

/**
 *
 * @author 
 */
public class GestorDeTareas {
    private static Lista<Usuario> usuarios = new Lista();
    private static Lista<Tarea> tareas = new Lista();
    private static Usuario usuarioActual = null;
    private static Scanner sc = new Scanner(System.in);
    private static int opcion;
    
    public static void main(String[] args) {
        usuarios = Txt.cargarUsuarios();
        tareas = Txt.cargarTareas();
        boolean salir = false;
        do{
            System.out.println("\nBienvenido a Gestor de Tareas");
            System.out.println("1. Iniciar sesión");
            System.out.println("0. Salir");
            System.out.print("Ingrese una opción: ");
            opcion = sc.nextInt();

            switch (opcion) {
                case 1:
                    iniciarSesion();
                    if (usuarioActual != null) {
                        mostrarMenu();
                    }
                    break;
                case 0:
                    System.out.println("\nSaliendo del programa...");
                    Txt.guardarTareas(tareas);
                    Txt.guardarUsuarios(usuarios);
                    salir = true;
                    break;
                default:
                    System.out.println("\nOpción inválida. Intente de nuevo.");
                    break;
            }
        }while(!salir);
    }
    
    public static void iniciarSesion() {
        sc.nextLine(); // limpiar buffer
        System.out.print("\nIngrese nombre de usuario: ");
        String nombreUsuario = sc.nextLine();
        System.out.print("Ingrese contraseña: ");
        String contra = sc.nextLine();
        
        usuarioActual = null;
        for (int i=0; i < usuarios.largo; i++) {
            if (usuarios.get(i).getNombreUsuario().equals(nombreUsuario) && usuarios.get(i).getContra().equals(contra)) {
                usuarioActual = usuarios.get(i);
                System.out.println("\nSesión iniciada correctamente.");
                if (usuarioActual.isAdmin()) {
                    System.out.println("\n¡Bienvenido administrador!");
                    break;
                } else {
                    System.out.println("\n¡Bienvenido " + usuarioActual.getNombreUsuario() + "!");
                }
            }
        }
        if (usuarioActual == null) {
            System.out.println("\nError: ¡Nombre de Usuario o contraseña incorrecta!\n");
        }
    }

    public static void mostrarMenu() {
        boolean salir = false;
        do{
            System.out.println("\nMenu Principal");
            System.out.println("1. Crear Tarea");
            System.out.println("2. Organizar Tareas");
            System.out.println("3. Asignar Tarea");
            System.out.println("4. Actualizar Estado");
            if (usuarioActual.isAdmin()) {
                System.out.println("5. Crear Usuario");
                System.out.println("6. Crear Eliminar");
            }
            System.out.println("0. Salir");
            System.out.print("Ingrese una opción: ");
            opcion = sc.nextInt();

            switch (opcion) {
                case 1:
                    crearTarea();
                    break;
                case 2:
                    organizarTareas();
                    break;
                case 3:
                    asignarTareas();
                    break;
                case 4:
                    actualizarEstado();
                    break;
                case 5:
                    crearUsuario();
                    break;
                case 6:
                    eliminarUsuario();
                    break;
                case 0:
                    System.out.println("\nSeccion Cerrada...");
                    salir = true;
                    break;
                default:
                    System.out.println("Opción inválida. Intente de nuevo.");
                    break;
            }
        }while(!salir);
    }

    private static void crearTarea() {
        sc.nextLine(); // limpiar buffer
        System.out.println("\nCrear Tarea");
        System.out.print("Título de la tarea: ");
        String titulo = sc.nextLine();
        System.out.print("Breve descripción: ");
        String descripcion = sc.nextLine();
        System.out.print("Fecha límite: ");
        String fechaLimite = sc.nextLine();

        Tarea nuevaTarea = new Tarea(titulo, descripcion, fechaLimite);
        tareas.agregar(nuevaTarea);
        System.out.println("¡Tarea creada exitosamente!");
    }
    
    static String devolverListaEstado(String estado) {
        Lista<Tarea> lista = new Lista();
        Tarea tarea;
        for (int i=0; i < tareas.largo; i++) {
            tarea = tareas.get(i);
            if (estado.equals(tarea.getEstado())) {
                lista.agregar(tarea);
            }
        }
        if (!lista.estaVacio()) {
            return lista.toString();
        } else {
            return "No hay Tareas " + estado;
        }
    }
    
    private static void organizarTareas() {
        System.out.println("\nTareas Pendientes:");
        System.out.println(devolverListaEstado("Pendiente"));
        System.out.println("\nTareas Asignadas:");
        System.out.println(devolverListaEstado("Asignada"));
        System.out.println("\nTareas En Curso:");
        System.out.println(devolverListaEstado("En Curso"));
        System.out.println("\nTareas Completadas:");
        System.out.println(devolverListaEstado("Completada"));
    }
    
    static Lista<Tarea> devolverLista(String estado) {
        Lista<Tarea> lista = new Lista();
        Tarea tarea;
        for (int i=0; i < tareas.largo; i++) {
            tarea = tareas.get(i);
            if (estado.equals(tarea.getEstado())) {
                lista.agregar(tarea);
            }
        }
        return lista;
    }

    private static void asignarTareas() {
        sc.nextLine(); // limpiar buffer
        Lista<Tarea> lista = devolverLista("Pendiente");
        if (!lista.estaVacio()) {
            System.out.println("\nAsignar de Tarea");
            System.out.println("\nTareas Pendientes: ");
            System.out.println(lista.toString());
            System.out.print("Tarea numero: ");
            int op = sc.nextInt();
            Tarea tarea = lista.get(op);
            
            System.out.println("\nUsuarios: ");
            System.out.print(usuarios.toString());
            System.out.print("Usuario numero: ");
            op = sc.nextInt();
            Usuario usuario = usuarios.get(op);
            
            tarea.asignarUsuario(usuario);
        } else {
            System.out.println("No se puede asignar tarea porque no hay tareas pendiente.");
        }
    }

    private static void actualizarEstado() {
        sc.nextLine(); // limpiar buffer
        System.out.println("\nActualizar Estado");
        System.out.println("\nEstados: ");
        System.out.println("1. Asignada");
        System.out.println("2. En Curso");
        int op = sc.nextInt();
        
        Lista<Tarea> lista;
        if (op == 1) {
            lista = devolverLista("Asignada");
        } else {
            lista = devolverLista("En Curso");
        }
        
        System.out.println("\nTareas: ");
        System.out.println(lista.toString());
        System.out.print("Tarea numero: ");
        op = sc.nextInt();
        Tarea tarea = lista.get(op);

        if (tarea != null) {
            System.out.println("Tarea seleccionada: " + tarea.getTitulo());
            if ("Asignada".equals(tarea.getEstado()))
                tarea.marcarEnCurso();
            else {
                tarea.marcarCompletada();
            }
            System.out.println("¡Tarea actualizado!");
        } else {
            System.out.println("Error: ¡Tarea no encontrada!");
        }
    }

    private static void crearUsuario() {
        sc.nextLine(); // limpiar buffer
        System.out.println("\nCrear Usuario");
        System.out.print("Ingrese nombre: ");
        String nombre = sc.nextLine();
        System.out.print("Ingrese apellido: ");
        String apellido = sc.nextLine();
        System.out.print("Ingrese cédula: ");
        String cedula = sc.nextLine();
        System.out.print("Ingrese nombre de usuario: ");
        String nombreUsuario = sc.nextLine();
        System.out.print("Ingrese contraseña: ");
        String contra = sc.nextLine();
        System.out.print("Ingrese tipo de usuario | 1. administrador | 2. usuario estándar): ");
        int op = sc.nextInt();
        
        String tipoUsuario;
        if (op == 1) {
            tipoUsuario = "Administrador";
        } else {
            tipoUsuario = "Usuario";
        }

        Usuario nuevoUsuario = new Usuario(nombre, apellido, cedula, nombreUsuario, contra, tipoUsuario);
        usuarios.agregar(nuevoUsuario);
        System.out.println("¡Usuario creado exitosamente!");
    }

    private static void eliminarUsuario() {
        sc.nextLine();  
        System.out.println("\nEliminar Usuario");
        System.out.println("\nUsuarios: ");
        System.out.print(usuarios.toString());
        System.out.print("Usuario numero: ");
        int op = sc.nextInt();
        Usuario usuario = usuarios.get(op);
        
        if (usuarios.eliminar(usuario)) {
            System.out.println("Usuario eliminado.");
        } else {
            System.out.println("Error: ¡Usuario no encontrado!");
        }
    }
}

