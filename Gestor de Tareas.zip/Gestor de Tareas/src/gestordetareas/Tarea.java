/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestordetareas;

/**
 *
 * @author
 */
public class Tarea {
    private String titulo;
    private String descripcion;
    private String fechaLimite;
    private String estado; // "Pendiente", "Asignada", "En Curso", "Completada"
    private Lista<Usuario> usuariosAsignados = new Lista();

    public Tarea(String titulo, String descripcion, String fechaLimite) {
        this.titulo = titulo;
        this.descripcion = descripcion;
        this.fechaLimite = fechaLimite;
        this.estado = "Pendiente";
    }

    public Tarea(String titulo, String descripcion, String fechaLimite, String estado) {
        this.titulo = titulo;
        this.descripcion = descripcion;
        this.fechaLimite = fechaLimite;
        this.estado = estado;
    }
    
    

    public String getTitulo() {
        return titulo;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public String getFechaLimite() {
        return fechaLimite;
    }

    public String getEstado() {
        return estado;
    }

    public String getUsuariosAsignado() {
        String texto = "";
        Usuario usuario;
        for (int i=0; i < usuariosAsignados.largo; i++) {
            usuario = usuariosAsignados.get(i);
            texto += usuario.getNombreUsuario();
            if (i < usuariosAsignados.largo - 1) {
                texto += "~";
            }
        }
        if ("".equals(texto)) {
            return "N/A";
        }
        return texto;
    }

    public void asignarUsuario(Usuario usuario) {
        this.usuariosAsignados.agregar(usuario);
        this.estado = "Asignada";
    }

    public void marcarEnCurso() {
        if (estado.equals("Asignada")) {
            estado = "En Curso";
        } else {
            System.out.println("No se puede cambiar el estado a 'En Curso' porque la tarea no está asignada.");
        }
    }

    public void marcarCompletada() {
        if (estado.equals("En Curso")) {
            estado = "Completada";
        } else {
            System.out.println("No se puede cambiar el estado a 'Completada' porque la tarea no está en curso.");
        }
    }
    
    public String mostrarUsuariosAsignados() {
        String texto = ""; 
        for (int i = 0; i < usuariosAsignados.largo; i++) {
            Usuario usuario = usuariosAsignados.get(i);
            texto += usuario.getNombreUsuario();
            if (i < usuariosAsignados.largo - 1) {
                texto += ", ";
            }
        }
        return texto;
    }

    @Override
    public String toString() {
        return "Título: " + titulo + ", Descripción: " + descripcion + ", Fecha Límite: " + fechaLimite + ", Estado: " + estado + ", Usuarios Asignados: " + (!usuariosAsignados.estaVacio() ? mostrarUsuariosAsignados() : "N/A");
    }
}
