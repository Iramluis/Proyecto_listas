/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestordetareas;

/**
 *
 * @author
 */
import java.util.Scanner;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Paths;

public class Txt {
    
    static String rutaActual = Paths.get("").toAbsolutePath().toString();
    static String usuariosTxt = rutaActual + "\\src\\gestordetareas\\usuarios.txt"; 
    static String tareasTxt = rutaActual + "\\src\\gestordetareas\\tareas.txt"; 


    public static Lista<Usuario> cargarUsuarios() {
        Lista<Usuario> usuarios = new Lista();
        Usuario usuario;
        try {
            Scanner leer = new Scanner(new FileReader(usuariosTxt));
            String nombre, apellido, cedula, nombreDeUsuario, contra, tipoUsuario;
            while (leer.hasNextLine()) {
                String line = leer.nextLine();
                String[] separado = line.split("-");
                nombre = separado[0];
                apellido = separado[1];
                cedula = separado[2];
                nombreDeUsuario = separado[3];
                contra = separado[4];
                tipoUsuario = separado[5];
                usuario = new Usuario(nombre, apellido, cedula, nombreDeUsuario, contra, tipoUsuario);
                usuarios.agregar(usuario);
            }
        } catch (FileNotFoundException fnfe) {
            System.out.println("El archivo \"usuarios.txt\" no encontrado.");
        } catch (IOException ioe) {
             System.out.println("El archivo \"usuarios.txt\" no se puede leer.");
        }
        return usuarios;
    }
    
    public static void guardarUsuarios(Lista<Usuario> usuarios) {
        FileWriter file = null;
        BufferedWriter bw = null;
        try {
            file = new FileWriter(usuariosTxt, false);
            bw = new BufferedWriter(file);
            Usuario usuario;
            for (int i = 0; i < usuarios.largo; i++) {
                usuario = usuarios.get(i);
                bw.write(usuario.getNombre() + "-" + usuario.getApellido() + "-" + usuario.getCedula() + "-" + usuario.getNombreUsuario()+ "-" + usuario.getContra()+ "-" + usuario.getTipoUsuario());
                bw.newLine();
            }            
            bw.flush();
        } catch (FileNotFoundException fnfe) {
            System.out.println("El archivo \"usuarios.txt\" no encontrado.");
        } catch (IOException ioe) {
            System.out.println("El archivo \"usuarios.txt\" no se puede leer.");
        } finally {
            try {
                if(bw != null) { 
                    bw.close();
                }
                if(file != null) { 
                    file.close();
                } 
            } catch (IOException ioe) { }
        }
    }
    
    public static Lista<Tarea> cargarTareas() {
        Lista<Tarea> tareas = new Lista();
        Tarea tarea;
        try {
            Scanner leer = new Scanner(new FileReader(tareasTxt));
            String titulo, descripcion, fechaLimite, estado, asignados;
            int id;
            Lista<Usuario> usuarios = cargarUsuarios();
            while (leer.hasNextLine()) {
                String line = leer.nextLine();
                String[] separado = line.split("-");
                titulo = separado[0];
                descripcion = separado[1];
                fechaLimite = separado[2];
                estado = separado[3];
                asignados = separado[4];
                tarea = new Tarea(titulo, descripcion, fechaLimite, estado);
                
                if (!"N/A".equals(asignados)) {
                    // Asignar usuarios a una tarea
                    String[] usuariosAsignados = asignados.split("~");
                    Usuario usuario;
                    for (int i = 0; i < usuariosAsignados.length; i++) {
                        for (int j=0; i < usuarios.largo; i++) {
                            usuario = usuarios.get(j);
                            if (usuario.getNombreUsuario().equals(usuariosAsignados[j])) {
                                tarea.asignarUsuario(usuario);
                            }
                        }
                    }
                }
                tareas.agregar(tarea);
            }
        } catch (FileNotFoundException fnfe) {
            System.out.println("El archivo \"tareas.txt\" no encontrado.");
        } catch (IOException ioe) {
             System.out.println("El archivo \"tareas.txt\" no se puede leer.");
        }
        return tareas;
    }
    
    public static void guardarTareas(Lista<Tarea> tareas) {
        FileWriter file = null;
        BufferedWriter bw = null;
        try {
            file = new FileWriter(tareasTxt, false);
            bw = new BufferedWriter(file);
            Tarea tarea;
            for (int i = 0; i < tareas.largo; i++) {
                tarea = tareas.get(i);
                bw.write(tarea.getTitulo() + "-" + tarea.getDescripcion() + "-" + tarea.getFechaLimite() + "-" + tarea.getEstado() + "-" + tarea.getUsuariosAsignado() );
                bw.newLine();
            }            
            bw.flush();
        } catch (FileNotFoundException fnfe) {
            System.out.println("El archivo \"tareas.txt\" no encontrado.");
        } catch (IOException ioe) {
            System.out.println("El archivo \"tareas.txt\" no se puede leer.");
        } finally {
            try {
                if(bw != null) { 
                    bw.close();
                }
                if(file != null) { 
                    file.close();
                } 
            } catch (IOException ioe) { }
        }
    }
}
