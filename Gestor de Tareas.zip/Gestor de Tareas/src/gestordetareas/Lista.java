/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestordetareas;

/**
 *
 * @author
 * @param <T>
 */
public class Lista<T> {

    private Nodo<T> primero;
    public int largo;

    public Lista() {
        this.primero = null;
        this.largo = 0;
    }

    public Lista(T info) { 
        this.primero = new Nodo(info);
    }

    public boolean estaVacio() {
        return (primero == null);
    }

    public boolean buscar(T referencia) {
        Nodo aux = primero;
        boolean encontrado = false;
        while (aux != null && encontrado != true) {
            if (referencia == aux.getInfo()) {
                encontrado = true;
            } else {
                aux = aux.getSig();
            }
        }
        return encontrado;
    }

    public int getPosicion(T info) {
        if (buscar(info)) {
            Nodo aux = primero;
            int cont = 0;
            while (info != aux.getInfo()) {
                cont++;
                aux = aux.getSig();
            }
            return cont;
        }
        return 0;
    }

    public void agregar(T info) {
        Nodo nuevo = new Nodo(info);
        if (estaVacio()) {
            primero = nuevo;
        } else {
            Nodo aux = primero;
            while (aux.getSig() != null) {
                aux = aux.getSig();
            }
            aux.setSig(nuevo);
        }
        largo++;
    }
    
    public T get(int posicion) {
        if (posicion >= 0 && posicion < largo) {
            if (posicion == 0) {
                return primero.getInfo();
            } else {
                Nodo<T> aux = primero;
                for (int i = 0; i < posicion; i++) {
                    aux = aux.getSig();
                }
                return aux.getInfo();
            }
        } else {
            return null;
        }
    }

    public boolean editar(T buscar, T info) {
        if (buscar(buscar)) {
            Nodo aux = primero;
            while (aux.getInfo() != buscar) {
                aux = aux.getSig();
            }
            aux.setInfo(info);
            return true;
        } else {
            return false;
        }
    }

    public boolean eliminar(T buscar) {
        if (buscar(buscar)) {
            if (primero.getInfo() == buscar) {
                primero = primero.getSig();
            } else {
                Nodo aux = primero;
                while (aux.getSig().getInfo() != buscar) {
                    aux = aux.getSig();
                }
                Nodo siguiente = aux.getSig().getSig();
                aux.setSig(siguiente);
            }
            largo--;
            return true;
        } else {
            return false;
        }
    }

    @Override
    public String toString() {
        String texto = "";
        if (!estaVacio()) {
            Nodo aux = primero;
            int i = 0;
            while (aux != null) {
                texto += i + ". " + aux.getInfo().toString() + "\n";
                aux = aux.getSig();
                i++;
            }
        }
        return texto;
    }
}
